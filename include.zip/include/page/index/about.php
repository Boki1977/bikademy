

        
        <div class="card card-style" style="margin-top: 55%; padding:5%;">
<h3>Cycle Your Exams</h3><br>
Bikademy is innovative cycling tourism concept with motto – Cycle Your Exams! It promotes micro regions as desirable cyclotourist destination in a interactive, educational and funny way.

<br><br> Basis of this product is platform with fields of studies that represent certain regions or cities. Each study has its own exams (locations).<br><br> Exams are passed when user called Bike Student, visit that location by bicycle and take a selfie at location.

First step for every user is registration, and with it, user gets an Index with studies and exams. The Bike Student can pass exams by random selection.

After passing every exam of certain study, Bike Student gets reward.

<p>

<h3>HOW TO PASS EXAM</h3><br>
Registration – for every new User (Bike Student)<br>

Task – visit locations (exams) of certain Studies by bicycle<br>

Take a selfie with bike at location through application (GPS and data have to be turned on)<br>

After passing every exam of certain Study – You get reward<br>

You can pass exams randomly<br>
                       
        </div> 
		