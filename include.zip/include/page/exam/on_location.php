     <div class="static-notification bg-blue-dark">
                  <div id="dist_div" style="color: white;"></div>
                    </div>  
        
        
            <div id="dist_div"></div>
            <div id="map-canvas"/>
			
			<?php echo $lat; ?>