

        
        <div class="card card-style" style="margin-top: 30%; position:relative;">		
		<a href="polaganje_lokacije.php?lokacija_id=<?php echo $lokacija_id; ?>"><img src="data/source/icons/addon.png" class="img-fluid"></a>       
        </div> 
		
		<div class="card card-style">		
		<a href="?page=add_off&lokacija_id=<?php echo $lokacija_id; ?>"><img src="data/source/icons/addout.png" class="img-fluid"></a>       
        </div> 
		
