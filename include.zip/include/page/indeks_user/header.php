<div class="card card-style" style="margin-top: 50%;">
 <div class="row mt-3 pt-1 mb-3">
     <div class="col-4"><img src="<?php echo $k_fotka; ?>" class="img-fluid" style="padding-left:2%;"></div>                    
     <div class="col-8"><h3><?php echo "$k_ime $k_prezime"; ?></h3></div>                    
    </div>
</div>