

	<?php
	include("header.php");
	?> 
					
	 <a href="?page=study_regions&reg=0">
        
        <div class="card card-style">
            <img src="data/source/bg/regions_exam.png" class="img-fluid">
                       
        </div> 
		</a>		
		<a href="?page=study_regions&reg=1">
		<div class="card card-style">
          <img src="data/source/bg/cities_exam.png" class="img-fluid">
                       
        </div> 
       </a>
				
					
					
					
        