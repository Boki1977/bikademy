<?php
$k_id =($obj->id);
$k_ime =($obj->ime);
$k_prezime =($obj->prezime);
$k_email =($obj->email);
$k_nadimak =($obj->nadimak);
$k_lozinka =($obj->lozinka);
$k_status =($obj->status);
$k_datum =($obj->datum);
$k_br_polaganja =($obj->br_polaganja);
$k_user_id =($obj->user_id);
$k_datum_rodjenja =($obj->datum_rodjenja);
$k_drzava =($obj->drzava);
$k_mjesto =($obj->mjesto);
$k_kod_korisnika =($obj->kod_korisnika);
$k_fotka =($obj->fotka);


if($k_fotka==''){
	
	$k_fotka="$image_path/demo/data/source/icons/user.jpg";
}

else{
	$k_fotka==$k_fotka;
}

?>